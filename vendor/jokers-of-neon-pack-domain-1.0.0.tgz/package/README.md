# Pack domain

The single source of the `core-pack-lcg-v1` reducer. Both independently deployed
services install the same versioned tarball from `vendor/`, pinned by their lockfiles.
Do not edit the worker's re-export or keep a separate reducer in either service.

To release: build this directory, run `npm pack --pack-destination ../../vendor`,
copy the archive to the worker's `vendor/`, then install the archive in both
repositories. Keep the source version and both archives/lockfiles in the change.
The local Core parity suite verifies the catalog probabilities and every card field.

The package also owns mint payload hashes, receipt acceptance policies, processing
leases and the Starknet commerce verifier/observer. Discovery only supplies
candidates to that verifier; it cannot authorize delivery from an event alone.
Submitted hashes, recent discovery and historical finality have independent loops.
